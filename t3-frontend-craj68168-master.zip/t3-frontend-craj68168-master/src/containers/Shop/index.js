import React, { Component } from 'react';
import './style.css';
import ShopStore from '../../components/ShopStore/ShopStore';

class Shop extends Component{
    render(){
        return (
            <ShopStore />
        );
    }
}

export default Shop;